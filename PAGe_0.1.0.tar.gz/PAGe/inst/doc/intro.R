## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# library(PAGe)
# 
# # Historical surveillance data shipped with the package.
# allD <- load_flu_hist()
# 
# # M0: ignition detection.
# m0 <- build_m0(allD)
# 
# # M1: reference curve + alignment hyperparameters.
# m1 <- build_m1(allD, m0)
# 
# # M2: forecast GAM (uses the pre-tuned production spec).
# m2 <- train_m2(allD, m0, m1, best_spec = NULL)
# 
# # Bundle everything a deployment needs into one list.
# kit <- assemble_kit(m0, m1, m2)

## -----------------------------------------------------------------------------
# current <- getCurrentD(season = "2025-26")
# res <- run_pipeline(kit, current)
# plot_forecast(res, history = allD)

